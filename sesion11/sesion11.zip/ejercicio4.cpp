/*
 * Calcula la moda de un vector de caracteres.
 */

/* 
 * File:   ejercicio4.cpp
 * Author: Mario Antonio López Ruiz
 *
 * Created on 10 de noviembre de 2016, 19:23
 */

#include <iostream>
#include <fstream>
using namespace std;

struct FrecuenciaCaracter{
	char caracter;
	int frecuencia;
};

int main(){
	const int TAMANIO = 25e+5;
	FrecuenciaCaracter moda;
	const char CENTINELA = '#';
	char caracteres[TAMANIO];
	char entrada[TAMANIO];
	char procesados[TAMANIO];
	int contador = 0,j,i, contador_char = 0;
	int valor;

	moda.frecuencia = -1;

	//------------- DUDA CLASE --------------
	/**ifstream fe("Quijo_sin_espacios.txt");

	while(!fe.eof()){
		fe >> caracteres;
		//cout << caracteres << endl;
	}
	fe.close();

	for(int i=0; i<TAMANIO; i++)
		cout << caracteres[i];
	**/

	cout << "\nIntroduzca los caractéres: ";
	caracteres[contador] = cin.get();
	while (caracteres[contador] != CENTINELA){
		contador++;		
		caracteres[contador] = cin.get();
		
	}


	for(i = '!'; i <= '~'; i++){
		for(j=0; j < contador; j++){
			valor = caracteres[j];

			if(i==valor)
				contador_char++;

			if(contador_char > moda.frecuencia){
				moda.frecuencia = contador_char;

				moda.caracter = i;
			}
		}
		contador_char = 0; //Reinicio
	}

	cout << "\nLa moda es: " << moda.caracter << " y aparece " << moda.frecuencia << " veces. " << endl;

}
